import pandas as pd
from datetime import datetime
from twilio.rest import Client

# Twilio credentials
account_sid = 'ACf1f4d57f73d7481e06110100b8d7e824'
auth_token = '2fd831edf60a7855000d8fa35857087c'
twilio_whatsapp_number = 'whatsapp:+14155238886'  # Replace with your Twilio WhatsApp sandbox number

# Initialize the Twilio client
client = Client(account_sid, auth_token)

# Function to send a WhatsApp message
def send_whatsapp_message(phone_number, message):
    client.messages.create(
        from_=twilio_whatsapp_number,
        body=message,
        to=f'whatsapp:{phone_number}'
    )

# Function to check for today's events and send messages
def check_and_send_messages():
    # Read the Excel file
    data = pd.read_excel("C:/New folder/contact.xlsx")  # Use the correct path to your file

    # Convert the 'Date' column to datetime (this is crucial)
    data['Date'] = pd.to_datetime(data['Date'], errors='coerce')

    # Get today's date
    today = datetime.today().strftime('%Y-%m-%d')
    messages_sent = False  # Track if any message was sent

    # Loop through each row in the Excel file
    for index, row in data.iterrows():
        if pd.isna(row['Date']):
            print(f"Skipping row {index} due to invalid date.")
            continue  # Skip invalid dates
        
        # Format the event date as 'YYYY-MM-DD' for comparison
        event_date = row['Date'].strftime('%Y-%m-%d')
        
        if event_date == today:
            # Generate a custom message based on the event
            if row['Event'].lower() == "birthday":
                message = f"Happy Birthday, {row['Name']}! 🎉 Hope you have a fantastic day!"
            elif row['Event'].lower() == "anniversary":
                message = f"Happy Anniversary, {row['Name']}! 💖 Wishing you a lifetime of love and happiness!"
            else:
                message = f"Happy {row['Event']}, {row['Name']}!"

            # Send the message
            send_whatsapp_message(row['Phone'], message)
            print(f"Message sent to {row['Phone']} for {row['Event']} of {row['Name']}")
            messages_sent = True  # Set to True if at least one message is sent

    # Check if any messages were sent and print the appropriate message
    if not messages_sent:
        print("No messages to send today.")

# Call the function directly for immediate execution
check_and_send_messages()
